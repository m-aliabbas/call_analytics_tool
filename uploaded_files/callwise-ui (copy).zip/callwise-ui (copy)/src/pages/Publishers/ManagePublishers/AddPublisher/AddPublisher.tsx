import React, { useState, useEffect, MouseEventHandler } from "react";
import {
  Box,
  Button,
  FormControl,
  selectClasses,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";

import theme from "../../../../styles/theme";
import CustomFormField from "../../../../components/customFormField/CustomFormField";
import ChevronDown from "../../../../components/icons/chevronDown";
import CustomLabel from "../../../../components/customLabel/CustomLabel";
import CustomSwitch from "../../../../components/switch/Switch";
import { SingleSelect } from "../../../../components/dynamicDropdown/DynamicDropdown";

function AddPublisher(): JSX.Element {
  const options = [
    {
      value: 10,
      component: OptionComponent({ countryName: "UAE", symbol: "ae" }),
    },
    {
      value: 20,
      component: OptionComponent({ countryName: "USA", symbol: "us" }),
    },
    {
      value: 30,
      component: OptionComponent({ countryName: "China", symbol: "cn" }),
    },
  ];

  function OptionComponent({ countryName, symbol }) {
    return (
      <Box display="flex" justifyContent="space-between" width="100%">
        <Typography className="title-medium" color="var(--blackColor)">
          {countryName}
        </Typography>
        <img
          src={`https://flagcdn.com/16x12/${symbol.toLowerCase()}.png`}
          className="object-contain"
          alt={countryName}
        />
      </Box>
    );
  }

  function CountryDropdown({ className }) {
    return (
      <SingleSelect
        className={className}
        label="Country"
        options={options}
      />
    );
  }

  return (
    <Box className="px-6 py-7">
      <Typography
        className="headline-medium"
        marginBottom="16px"
        color={theme.palette.primary.main}
      >
        Add Publisher
      </Typography>
      <Typography
        className="body-small max-w-[494px]"
        color="var(--blackColor)"
      >
        Enter information about a new publisher to track their calls and analyze
        their performance. Publishers are entities or individuals who promote
        your products or services and generate phone leads for your business. By
        adding publishers to your call tracking system, you can measure the
        effectiveness of their campaigns and optimize your marketing strategy.
      </Typography>
      <Box height="96px" />
      <Box className="flex justify-center">
        <div className="grid gap-8 grid-cols-10 w-full max-w-2xl">
          <div className="flex justify-end items-center gap-x-1.5 col-span-3">
            <CustomLabel label="Name" />
          </div>
          <div className="col-span-1" />
          <CustomFormField className="col-span-6" label="Publisher Name" />

          <div className="flex justify-end items-center col-span-3">
            <CustomLabel label="Number creation" />
          </div>
          <div className="col-span-1" />
          <div className="col-span-6">
            <CustomSwitch />
          </div>
          <div className="flex justify-end items-center gap-x-1.5 col-span-3">
            <CustomLabel label="Access to recordings" />
          </div>
          <div className="col-span-1" />
          <div className="col-span-6">
            <CustomSwitch />
          </div>
          <div className="col-span-4" />
          <div className="mt-[56px] flex col-span-6 justify-start">
            <Button
              variant="outlined"
              className="title-medium"
              sx={{
                padding: "8.5px 16px",
                textTransform: "none",
                width: "100%",
                maxWidth: "150px",
                border: "1px solid var(--blackColor)",
                color: "var(--blackColor)",
                borderRadius: "5px",
                marginRight: "16px",
                "&:hover": {
                  color: "var(--redColor)",
                  borderColor: "var(--redColor)",
                },
              }}
            >
              Cancle
            </Button>
            <Button
              variant="contained"
              className="title-medium"
              sx={{
                padding: "8.5px 16px",
                textTransform: "none",
                width: "100%",
                maxWidth: "150px",
                color: "#fff",
                borderRadius: "5px",
                boxShadow: "unset !important",
              }}
            >
              Create
            </Button>
          </div>
        </div>
      </Box>
    </Box>
  );
}

export default AddPublisher;
