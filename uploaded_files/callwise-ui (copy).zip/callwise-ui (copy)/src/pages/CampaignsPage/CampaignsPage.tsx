import React, { useState, useEffect } from "react";
import "./CampaignsPage.scss";
import { Box, Button, Typography } from "@mui/material";
import theme from "../../styles/theme";
import plusIcon from "../../assets/img/icons/plus.svg";
import ReusableTable from "../../components/basicTable/BasicTable";
import { useNavigate } from "react-router-dom";
import EditIcon from "../../components/icons/edit";
import DeleteIcon from "../../components/icons/delete";
import StatsIcon from "../../components/icons/stats";
import PauseIcon from "../../components/icons/pause";
import PlusIcon from "../../components/icons/plus";

function CampaignsPage(): JSX.Element {
  const navigate = useNavigate();
  // Example usage
  const columns = [
    { title: "Name", align: "left" },
    { title: "Country", align: "center" },
    { title: "Connected Calls", align: "center" },
    { title: "Live", align: "center" },
    { title: "Average Call Duration", align: "center" },
    { title: "Total", align: "center" },
    { title: "Status", align: "center" },
    { title: "Actions", align: "right" },
  ];
  

  const rows = [
    {
      name: { value: "TeleTechServices", align: "left" },
      country: { value: "US", align: "center" },
      connectedCalls: { value: 159, align: "center" },
      live: { value: 6.0, align: "center" },
      averageCallDuration: { value: 24, align: "center" },
      total: { value: 4.0, align: "center" },
      status: { value: "Active", align: "center" },
      actions: { 
        value: [
          { icon: <EditIcon />, onClick: () => {} },
          { icon: <DeleteIcon />, onClick: () => {} },
          { icon: <StatsIcon />, onClick: () => {} },
          { icon: <PauseIcon />, onClick: () => {} },
        ],
        align: "right" 
      },
    },
    {
      name: { value: "CallLink USA", align: "left" },
      country: { value: "Ae", align: "center" },
      connectedCalls: { value: 159, align: "center" },
      live: { value: 6.0, align: "center" },
      averageCallDuration: { value: 24, align: "center" },
      total: { value: 4.0, align: "center" },
      status: { value: "Inactive", align: "center" },
      actions: { 
        value: [
          { icon: <EditIcon />, onClick: () => {} },
          { icon: <DeleteIcon />, onClick: () => {} },
          { icon: <StatsIcon />, onClick: () => {} },
          { icon: <PauseIcon />, onClick: () => {} },
        ],
        align: "right" 
      },
    },
    {
      name: { value: "Customer Care", align: "left" },
      country: { value: "Ae", align: "center" },
      connectedCalls: { value: 159, align: "center" },
      live: { value: 6.0, align: "center" },
      averageCallDuration: { value: 24, align: "center" },
      total: { value: 4.0, align: "center" },
      status: { value: "Inactive", align: "center" },
      actions: { 
        value: [
          { icon: <EditIcon />, onClick: () => {} },
          { icon: <DeleteIcon />, onClick: () => {} },
          { icon: <StatsIcon />, onClick: () => {} },
          { icon: <PauseIcon />, onClick: () => {} },
        ],
        align: "right" 
      },
    },
    {
      name: { value: "Proactive Solutions", align: "left" },
      country: { value: "Ae", align: "center" },
      connectedCalls: { value: 159, align: "center" },
      live: { value: 6.0, align: "center" },
      averageCallDuration: { value: 24, align: "center" },
      total: { value: 4.0, align: "center" },
      status: { value: "Inactive", align: "center" },
      actions: { 
        value: [
          { icon: <EditIcon />, onClick: () => {} },
          { icon: <DeleteIcon />, onClick: () => {} },
          { icon: <StatsIcon />, onClick: () => {} },
          { icon: <PauseIcon />, onClick: () => {} },
        ],
        align: "right" 
      },
    },
    // Additional rows...
  ];
  

  function CampaignsTable() {
    return <ReusableTable columns={columns} rows={rows} />;
  }
  return (
    <Box className="px-6 py-7">
      <Typography
        className="headline-medium"
        marginBottom="34px"
        color={theme.palette.primary.main}
      >
        Manage Campaign
      </Typography>
      <Button
        variant="outlined"
        startIcon={<PlusIcon color="var(--redColor)" />}
        className="title-medium"
        sx={{
          padding: "8.5px 16px",
          textTransform: "none",
          border: "1px solid #E01E26",
          color: "#E01E26",
          marginBottom: "24px",
          borderRadius: "5px",
          "&:hover": {
            color: "#fff",
            backgroundColor: "var(--redColor)",
            '& svg':{
              fill: '#fff'
            }
          },
        }}
        onClick={() => navigate("/campaigns/create")}
      >
        Create Campaign
      </Button>
      <CampaignsTable />
    </Box>
  );
}

export default CampaignsPage;
