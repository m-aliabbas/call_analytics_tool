import React, { useState, useEffect } from "react";
import "./CommandCentre.scss";

function CommandCentre(): JSX.Element {

  return (
    <div >
      CommandCentre
    </div>
  );
}

export default CommandCentre;
