import {
  Box,
  Typography,
  Button,
  InputAdornment,
  TextField,
} from "@mui/material";
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

import ReusableTable from "../../components/basicTable/BasicTable";
import EditIcon from "../../components/icons/edit";
import PauseIcon from "../../components/icons/pause";
import PlusIcon from "../../components/icons/plus";
import theme from "../../styles/theme";
import SearchIcon from "../../components/icons/search";
import DeleteIcon from "../../components/icons/delete";
import CustomFormField from "../../components/customFormField/CustomFormField";
import CustomLabel from "../../components/customLabel/CustomLabel";
import DynamicTabs from "../../components/dynamicTabs/DynamicTabs";
import CustomModal from "../../components/modal/Modal";
import { CountryDropdown } from "../../components/dynamicDropdown/CountryDropdown";
import NumberDropdown from "../../components/dynamicDropdown/NumberDropdown";
import { SingleSelect } from "../../components/dynamicDropdown/DynamicDropdown";

function ManageNumbers(): JSX.Element {

  const [openNumberModal, setOpenNumberModal] = useState<boolean>(false);
  const [selectedTab, setSelectedTab] = useState("one");

  const handleTabChange = (event, newValue) => {
    setSelectedTab(newValue);
  };

  const tabs = [
    { value: "one", label: "Toll Free" },
    { value: "two", label: "Local" },
  ];

  const columns = [
    { title: "Number", align: "left" },
    { title: "Publisher", align: "left" },
    { title: "Creation Date", align: "left" },
    { title: "Country", align: "center" },
    { title: "Status", align: "center" },
    { title: "Actions", align: "left" },
  ];

  const rows = [
    {
      number: { value: "+1 (908) 334 2046", align: "left" },
      publisher: { value: "Callhub Medi Publisher", align: "left" },
      date: { value: "12/02/2022", align: "left" },
      country: { value: "us", align: "center" },
      status: { value: "Active", align: "center" },
      actions: {
        value: [
          { icon: <PauseIcon />, onClick: () => {} },
          { icon: <EditIcon />, onClick: () => {} },
          { icon: <DeleteIcon />, onClick: () => {} },
        ],
        align: "left",
      },
    },
    {
      number: { value: "+1 (908) 200 2111", align: "left" },
      publisher: { value: "Callhub Medi Publisher", align: "left" },
      date: { value: "27/07/2022", align: "left" },
      country: { value: "us", align: "center" },
      status: { value: "Active", align: "center" },
      actions: {
        value: [
          { icon: <PauseIcon />, onClick: () => {} },
          { icon: <EditIcon />, onClick: () => {} },
          { icon: <DeleteIcon />, onClick: () => {} },
        ],
        align: "left",
      },
    },
    {
      number: { value: "+1 (908) 334 2371", align: "left" },
      publisher: { value: "Callassist Solar Publisher", align: "left" },
      date: { value: "03/05/2023", align: "left" },
      country: { value: "us", align: "center" },
      status: { value: "Active", align: "center" },
      actions: {
        value: [
          { icon: <PauseIcon />, onClick: () => {} },
          { icon: <EditIcon />, onClick: () => {} },
          { icon: <DeleteIcon />, onClick: () => {} },
        ],
        align: "left",
      },
    },
    {
      number: { value: "+1 (908) 872 1559", align: "left" },
      publisher: { value: "Dialease Solar Publisher", align: "left" },
      date: { value: "12/02/2023", align: "left" },
      country: { value: "us", align: "center" },
      status: { value: "Active", align: "center" },
      actions: {
        value: [
          { icon: <PauseIcon />, onClick: () => {} },
          { icon: <EditIcon />, onClick: () => {} },
          { icon: <DeleteIcon />, onClick: () => {} },
        ],
        align: "left",
      },
    },
    {
      number: { value: "+1 (908) 872 1601", align: "left" },
      publisher: { value: "You", align: "left" },
      date: { value: "12/02/2023", align: "left" },
      country: { value: "us", align: "center" },
      status: { value: "Active", align: "center" },
      actions: {
        value: [
          { icon: <PauseIcon />, onClick: () => {} },
          { icon: <EditIcon />, onClick: () => {} },
          { icon: <DeleteIcon />, onClick: () => {} },
        ],
        align: "left",
      },
    },
  ];
  const publisherOptions = [
    {
      value: "Publisher-1",
      component: PublisherOptionComponent({ publisherName: "Publisher-1" }),
    },
    {
      value: "Publisher-2",
      component: PublisherOptionComponent({ publisherName: "Publisher-1" }),
    },
    {
      value: "Publisher-3",
      component: PublisherOptionComponent({ publisherName: "Publisher-1" }),
    },
  ];
  function PublisherOptionComponent({ publisherName }) {
    return (
      <Box>
        <Typography className="title-medium" color="var(--blackColor)">
          {publisherName}
        </Typography>
      </Box>
    );
  }

  function PublisherDropdown({ className = "" }) {
    return (
      <SingleSelect
        label="Select Available Publishers"
        options={publisherOptions}
        className={className}
      />
    );
  }

  function CampaignsTable() {
    return <ReusableTable columns={columns} rows={rows} />;
  }
  const SearchField = ({ placeholder }) => {
    return (
      <TextField
        sx={{
          maxWidth: "315px",
          "input::placeholder": {
            // opacity: "1 !important",
          },
          input: {
            color: "#000",
            fontFamily: "Roboto",
            fontSize: "12px",
            fontWeight: 400,
            lineHeight: "120%",
          },
          "& .MuiInputBase-input": {},
          "& .MuiInputBase-root": {
            borderRadius: "0px",
            border: "1px solid var(--blackColor) !important",
            padding: "2px 12px",
          },
          "& .MuiInput-root::before ,.MuiInput-root::after": {
            borderWidth: "0px !important",
          },
        }}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon color="var(--redColor)" />
            </InputAdornment>
          ),
        }}
        placeholder={placeholder}
        variant="standard"
      />
    );
  };
  return (
    <>
      <CustomModal
        openVerifyModal={openNumberModal}
        setOpenVerifyModal={setOpenNumberModal}
        minWidth={900}
        sx={{
          padding: "5% 5%",
        }}
      >
        <div className="grid gap-4 grid-cols-10 w-full gap-y-8">
          <div className="flex justify-end items-center col-span-3">
            <Typography className="title-small" color="var(--blackColor)">
              Country
            </Typography>
          </div>
          <div className="col-span-1" />
          <CountryDropdown className="col-span-6" />
          <div className="flex justify-end items-center gap-x-1.5 col-span-3">
            <CustomLabel label="Restrict After" helperText="s" />
          </div>
          <div className="col-span-1" />

          <div className="col-span-6 flex flex-col">
            <DynamicTabs
              tabs={tabs}
              className="w-full"
              selectedTab={selectedTab}
              handleTabChange={handleTabChange}
            />
          </div>
          <div className="flex justify-end items-center gap-x-1.5 col-span-3">
            <CustomLabel label="Prefix" />
          </div>
          <div className="col-span-1" />
          <CustomFormField className="col-span-6" label="Optional" />
          <div className="flex justify-end items-center gap-x-1.5 col-span-3">
            <CustomLabel
              label="Number"
              helperText="Select a number from the list created by the publisher"
            />
          </div>
          <div className="col-span-1" />
          <div className="col-span-6">
            <NumberDropdown />

            <Typography
              className="body-small"
              sx={{
                color: "var(--greyColor)",
                marginTop: "6px",
                marginBottom: "-20px",
              }}
            >
              Leave this blank to select a number at random.
            </Typography>
          </div>
          <div className="flex justify-end items-center gap-x-1.5 col-span-3">
            <CustomLabel label="Add to Publisher" />
          </div>
          <div className="col-span-1" />
          <PublisherDropdown className="col-span-6" />
          <div className="col-span-4" />
          <div className="col-span-6">
            <Button
              variant="contained"
              className="title-medium"
              sx={{
                padding: "8.5px 16px",
                textTransform: "none",
                width: "100%",
                maxWidth: "150px",
                color: "#fff",
                borderRadius: "5px",
                boxShadow: "unset !important",
                marginTop: "56px",
              }}
              onClick={() => setOpenNumberModal(true)}
            >
              Create
            </Button>
          </div>
        </div>
      </CustomModal>
      <Box className="px-6 py-7">
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          <Typography
            className="headline-medium"
            marginBottom="34px"
            color={theme.palette.primary.main}
          >
            Manage Numbers
          </Typography>
          <SearchField placeholder="Search Numbers" />
        </Box>
        <Button
          variant="outlined"
          startIcon={<PlusIcon color="var(--redColor)" />}
          className="title-medium"
          sx={{
            padding: "8.5px 16px",
            textTransform: "none",
            border: "1px solid #E01E26",
            color: "#E01E26",
            marginBottom: "24px",
            borderRadius: "5px",
            "&:hover": {
              color: "#fff",
              backgroundColor: "var(--redColor)",
              "& svg": {
                fill: "#fff",
              },
            },
          }}
          onClick={() => setOpenNumberModal(true)}
        >
          Create Number
        </Button>
        <CampaignsTable />
      </Box>
    </>
  );
}

export default ManageNumbers;
