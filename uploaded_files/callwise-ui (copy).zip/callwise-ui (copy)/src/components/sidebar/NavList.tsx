import React, { useEffect } from "react";
import ListSubheader from "@mui/material/ListSubheader";
import List from "@mui/material/List";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Collapse from "@mui/material/Collapse";
import ChevronDown from "../icons/chevronDown";
import { useLocation, useNavigate } from "react-router-dom";
import LogoutIcon from "../icons/logout";
import SettingsIcon from "../icons/settings";
import { Box, Button, Typography } from "@mui/material";
import theme from "../../styles/theme";
import CloudIcon from "../icons/cloud";
import CommandCenterIcon from "../icons/commandCenter";
import ReportingIcon from "../icons/reporting";
import CampaignsIcon from "../icons/campaigns";
import TargetsIcon from "../icons/targets";
import PublishersIcon from "../icons/publishers";
import NumbersIcon from "../icons/numbers";
import BillingsIcon from "../icons/billings";

function NavItemWithoutChildren({ text, link, isActive, setActive, Icon }) {
  return (
    <ListItemButton
      key={link + text}
      onClick={() => setActive(link)}
      className={isActive ? "active" : ""}
    >
      <ListItemIcon className="justify-center">
        {Icon && <Icon color={isActive ? "#fff" : undefined} />}
      </ListItemIcon>
      <ListItemText primary={text} />
    </ListItemButton>
  );
}

function NavItemWithCollapse({
  text,
  link,
  isActive,
  setActive,
  isOpen,
  Icon,
}) {
  return (
    <ListItemButton
      sx={{
        paddingRight: "25%",
      }}
      onClick={() => {
        setActive(link);
        // setOpen(!isOpen);
      }}
      className={isActive ? "active" : ""}
    >
      <ListItemIcon className="justify-center">
        {Icon && <Icon color={isActive ? "#fff" : undefined} />}
      </ListItemIcon>
      <ListItemText primary={text} />
      {isActive ? (
        <ChevronDown
          style={{
            rotate: "180deg",
            transition: "rotate 500ms",
          }}
          color="#fff"
        />
      ) : (
        <ChevronDown
          style={{
            rotate: "0deg",
            transition: "rotate 500ms",
          }}
        />
      )}
      {/* <ChevronDown color={isActive ? "#fff" : undefined} /> */}
    </ListItemButton>
  );
}

function SubMenu({ links, activeLink }) {
  const navigate = useNavigate();
  const location = useLocation();
  return (
    <Collapse in={true} timeout="auto" unmountOnExit>
      <List
        component="div"
        sx={{
          paddingY: "17px",
        }}
        disablePadding
      >
        {links.map((link) => {
          return (
            <ListItemButton
              onClick={() => navigate(link.link)}
              key={link.link}
              sx={{ pl: 6 }}
            >
              <ListItemIcon
                sx={{
                  minWidth: "unset",
                  paddingRight: "23px",
                }}
              >
                <Box
                  sx={{
                    width: 8,
                    height: 8,
                    borderRadius: "50%",
                    bgcolor: "var(--blackColor)",
                  }}
                />
              </ListItemIcon>
              <ListItemText
                className="sub-menu"
                sx={{
                  span: {
                    fontWeight:
                      link.link === location.pathname ||
                        location.pathname.includes(link.link + "/")
                        ? "500 !important"
                        : "400 !important",
                  },
                }}
                primary={link.text}
              />
            </ListItemButton>
          );
        })}
      </List>
    </Collapse>
  );
}

export default function NavList() {
  const [activeLink, setActiveLink] = React.useState("/");
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    setActiveLink(location.pathname);
  }, []);

  const handleItemClick = (link) => {
    setActiveLink(link);
    navigate(link);
  };

  const items = [
    {
      text: "Command Centre",
      link: "/",
      hasChildren: false,
      icon: CommandCenterIcon,
    },
    {
      text: "Reporting",
      // link: "/reporting",
      hasChildren: false,
      icon: ReportingIcon,
    },
    {
      text: "Campaigns",
      link: "/campaigns",
      hasChildren: false,
      icon: CampaignsIcon,
    },
    {
      text: "Publishers",
      link: "/publishers",
      hasChildren: true,
      icon: PublishersIcon,
      childrenLinks: [
        { text: "Manage Publishers", link: "/publishers" },
        { text: "Manage Group", link: "/publishers-group" },
      ],
    },
    {
      text: "Targets",
      link: "/manage-targets",
      hasChildren: true,
      icon: TargetsIcon,
      childrenLinks: [
        { text: "Manage Targets", link: "/manage-targets" },
        { text: "Manage Buyers", link: "/manage-buyers" },
        { text: "Manage Groups", link: "/buyer-groups" },
      ],
    },
    {
      text: "Numbers",
      hasChildren: true,
      icon: NumbersIcon,
      link: "/manage-numbers",
      childrenLinks: [
        { text: "Manage Numbers", link: "/manage-numbers" },
        { text: "Manage DNC", link: "/manage-dnc" },
      ],
    },
    {
      text: "Billing",
      hasChildren: false,
      icon: BillingsIcon,
    },
  ];

  const itemsBottom = [
    {
      text: "Settings",
      link: "/profile-settings",
      hasChildren: true,
      icon: SettingsIcon,
      childrenLinks: [
        { text: "Profile", link: "/profile-settings" },
        { text: "Manage Users", link: "/manage-users" },
      ],
    },
    {
      text: "Logout",
      hasChildren: false,
      icon: LogoutIcon,
    },
  ];

  return (
    <List
      sx={{ width: "100%", bgcolor: "background.paper", marginTop: "56px" }}
      component="nav"
      aria-labelledby="nested-list-subheader"
      className="nav-list"
    >
      {items.map((item) =>
        item.hasChildren ? (
          <React.Fragment key={item.link}>
            <NavItemWithCollapse
              text={item.text}
              link={item.link}
              isActive={
                activeLink === item.link ||
                item.childrenLinks?.some(
                  (e: any) =>
                    location.pathname == e.link ||
                    location.pathname.includes(e.link + "/")
                )
              }
              setActive={handleItemClick}
              isOpen={activeLink === item.link}
              Icon={item.icon && item.icon}
            />
            {(activeLink === item.link ||
              item.childrenLinks?.some(
                (e: any) =>
                  location.pathname == e.link ||
                  location.pathname.includes(e.link + "/")
              )) && (
                <SubMenu links={item.childrenLinks} activeLink={activeLink} />
              )}
          </React.Fragment>
        ) : (
          <NavItemWithoutChildren
            key={item.text}
            text={item.text}
            link={item.link}
            isActive={activeLink === item.link}
            setActive={handleItemClick}
            Icon={item.icon && item.icon}
          />
        )
      )}
      <Box height="50px" />
      <div className="mx-8">
        <Box className="flex gap-x-4">
          <CloudIcon width="30px" />
          <Box className="grow">
            <ListItemText primary="Storage" />
            <div className="progress-container my-3">
              <div className="progress-bar" style={{ width: `60%` }}></div>
            </div>
            <Typography
              variant="h1"
              fontFamily="Roboto"
              fontWeight="400"
              fontSize="12px"
              color={theme.palette.text.primary}
            >
              10 GB of 15 GB used
            </Typography>
            <Button
              sx={{
                fontFamily: "Roboto !important",
                fontWeight: "500",
                fontSize: "15px",
                textTransform: "none",
                border: "1px solid #E01E26",
                color: "#E01E26",
                marginTop: "10px",
                "&:hover": {
                  color: "#fff",
                  backgroundColor: "var(--redColor)",
                },
              }}
              variant="outlined"
            >
              Upgrade
            </Button>
          </Box>
        </Box>
      </div>
      <Box className="divider" />
      {itemsBottom.map((item) =>
        item.hasChildren ? (
          <React.Fragment key={item.link}>
            <NavItemWithCollapse
              text={item.text}
              link={item.link}
              isActive={
                activeLink === item.link ||
                item.childrenLinks?.some(
                  (e: any) => location.pathname == e.link
                )
              }
              setActive={handleItemClick}
              isOpen={activeLink === item.link}
              Icon={item.icon && item.icon}
            />
            {(activeLink === item.link ||
              item.childrenLinks?.some(
                (e: any) => location.pathname == e.link
              )) && (
                <SubMenu links={item.childrenLinks} activeLink={activeLink} />
              )}
          </React.Fragment>
        ) : (
          <NavItemWithoutChildren
            key={item.text}
            text={item.text}
            link={item.link}
            isActive={activeLink === item.link}
            setActive={handleItemClick}
            Icon={item.icon && item.icon}
          />
        )
      )}
      {/* <ListItemButton>
        <ListItemIcon className="justify-center">
          <SettingsIcon width="22" />
        </ListItemIcon>
        <ListItemText primary="Settings" />
      </ListItemButton>
      <ListItemButton>
        <ListItemIcon className="justify-center">
          <LogoutIcon width="22" />
        </ListItemIcon>
        <ListItemText primary="Logout" />
      </ListItemButton> */}
      <Box height="500px" />
    </List>
  );
}

// import * as React from "react";
// import ListSubheader from "@mui/material/ListSubheader";
// import List from "@mui/material/List";
// import ListItemButton from "@mui/material/ListItemButton";
// import ListItemIcon from "@mui/material/ListItemIcon";
// import ListItemText from "@mui/material/ListItemText";
// import Collapse from "@mui/material/Collapse";
// import commandCentre from "../../assets/img/icons/command-center.svg";
// import CommandCenter from "../icons/commandCenter";
// import ReportingIcon from "../icons/reporting";
// import CampaignsIcon from "../icons/campaigns";
// import PublishersIcon from "../icons/publishers";
// import BillingsIcon from "../icons/billings";
// import TargetsIcon from "../icons/targets";
// import NumbersIcon from "../icons/numbers";
// import { Box, Button, Typography } from "@mui/material";
// import CloudIcon from "../icons/cloud";
// import theme from "../../styles/theme";
// import SettingsIcon from "../icons/settings";
// import LogoutIcon from "../icons/logout";
// import { useLocation, useNavigate } from "react-router-dom";
// import { useEffect } from "react";
// import ChevronDown from "../icons/chevronDown";

// export default function NavList() {
//   const [open, setOpen] = React.useState(false);
//   const navigate = useNavigate();
//   const location = useLocation();

//   useEffect(() => {
//     // console.log(location);
//     if (
//       location.pathname === "/manage-targets" ||
//       location.pathname.includes("/manage-targets/") ||
//       location.pathname.includes("/manage-buyers/") ||
//       location.pathname === "/manage-buyers"
//     )
//       setOpen(true);
//     else setOpen(false);
//   }, [location.pathname]);

//   const handleClick = () => {
//     setOpen(!open);
//     console.log(location.pathname);
//   };

//   return (
//     <List
//       sx={{ width: "100%", bgcolor: "background.paper", marginTop: "56px" }}
//       component="nav"
//       aria-labelledby="nested-list-subheader"
//       className="nav-list"
//     >
//       <ListItemButton
//         className={`${location.pathname === "/" ? "active" : ""}`}
//         onClick={() => navigate("/")}
//       >
//         <ListItemIcon className="justify-center">
//           <CommandCenter
//             color={location.pathname === "/" ? "#fff" : undefined}
//             width="22"
//           />
//         </ListItemIcon>
//         <ListItemText
//           primary="Command Centre"
//           sx={{
//             "& .MuiTypography-root": {
//               fontFamily: "Roboto !important",
//               fontWeight: "500",
//               fontSize: "14px",
//               lineHeight: "14px",
//             },
//           }}
//         />
//       </ListItemButton>
//       <ListItemButton>
//         <ListItemIcon className="justify-center">
//           <ReportingIcon width="22" />
//         </ListItemIcon>
//         <ListItemText primary="Reporting" />
//       </ListItemButton>
//       <ListItemButton
//         onClick={() => navigate("/campaigns")}
//         className={`${
//           location.pathname === "/campaigns" ||
//           location.pathname.includes("/campaigns/")
//             ? "active"
//             : ""
//         }`}
//       >
//         <ListItemIcon className="justify-center">
//           <CampaignsIcon
//             color={
//               location.pathname === "/campaigns" ||
//               location.pathname.includes("/campaigns/")
//                 ? "#fff"
//                 : undefined
//             }
//             width="22"
//           />
//         </ListItemIcon>
//         <ListItemText primary="Campaigns" />
//       </ListItemButton>
//       <ListItemButton
//         onClick={() => navigate("/publishers")}
//         className={`${
//           location.pathname === "/publishers" ||
//           location.pathname.includes("/publishers/")
//             ? "active"
//             : ""
//         }`}
//       >
//         <ListItemIcon className="justify-center">
//           <PublishersIcon
//             width="22"
//             color={
//               location.pathname === "/publishers" ||
//               location.pathname.includes("/publishers/")
//                 ? "#fff"
//                 : undefined
//             }
//           />
//         </ListItemIcon>
//         <ListItemText primary="Publishers" />
//       </ListItemButton>
//       <ListItemButton>
//         <ListItemIcon className="justify-center">
//           <BillingsIcon width="22" />
//         </ListItemIcon>
//         <ListItemText primary="Billing" />
//       </ListItemButton>
//       <ListItemButton
//         onClick={() => {
//           navigate("/manage-targets");
//           handleClick();
//         }}
//         className={`${
//           location.pathname === "/manage-targets" ||
//           location.pathname.includes("/manage-targets/") ||
//           location.pathname.includes("/manage-buyers/") ||
//           location.pathname === "/manage-buyers"
//             ? "active"
//             : ""
//         }`}
//       >
//         <ListItemIcon className="justify-center">
//           <TargetsIcon
//             width="22"
//             color={
//               location.pathname === "/manage-targets" ||
//               location.pathname.includes("/manage-targets/") ||
//               location.pathname.includes("/manage-buyers/") ||
//               location.pathname === "/manage-buyers"
//                 ? "#fff"
//                 : undefined
//             }
//           />
//         </ListItemIcon>
//         <ListItemText primary="Targets" />
//         {open ? (
//           <ChevronDown
//             color={
//               location.pathname === "/manage-targets" ||
//               location.pathname.includes("/manage-targets/") ||
//               location.pathname.includes("/manage-buyers/") ||
//               location.pathname === "/manage-buyers"
//                 ? "#fff"
//                 : undefined
//             }
//           />
//         ) : (
//           <ChevronDown
//             color={
//               location.pathname === "/manage-targets" ||
//               location.pathname === "/manage-buyers"
//                 ? "#fff"
//                 : undefined
//             }
//           />
//         )}
//       </ListItemButton>
//       <Collapse in={open} timeout="auto" unmountOnExit>
//         <List component="div" disablePadding>
//           <ListItemButton
//             onClick={() => navigate("/manage-targets")}
//             sx={{ pl: 10 }}
//           >
//             <ListItemText
//               className="sub-menu"
//               sx={{
//                 span: {
//                   fontWeight:
//                     location.pathname === "/manage-targets" ||
//                     location.pathname.includes("/manage-targets/")
//                       ? "500 !important"
//                       : "400 !important",
//                 },
//               }}
//               primary="Manage Targets"
//             />
//           </ListItemButton>
//           <ListItemButton
//             onClick={() => navigate("/manage-buyers")}
//             sx={{ pl: 10 }}
//           >
//             <ListItemText
//               className="sub-menu"
//               sx={{
//                 span: {
//                   fontWeight:
//                     location.pathname === "/manage-buyers"
//                       ? "500 !important"
//                       : "400 !important",
//                 },
//               }}
//               primary="Manage Buyers"
//             />
//           </ListItemButton>
//         </List>
//       </Collapse>
//       <ListItemButton onClick={handleClick}>
//         <ListItemIcon className="justify-center">
//           <NumbersIcon width="22" />
//         </ListItemIcon>
//         <ListItemText primary="Numbers" />
//         {open ? (
//           <ChevronDown
//             color={
//               location.pathname === "/manage-targets" ||
//               location.pathname === "/manage-buyers"
//                 ? "#fff"
//                 : undefined
//             }
//           />
//         ) : (
//           <ChevronDown
//             color={
//               location.pathname === "/manage-targets" ||
//               location.pathname === "/manage-buyers"
//                 ? "#fff"
//                 : undefined
//             }
//           />
//         )}
//       </ListItemButton>
//       <Box height="50px" />
//       <div className="mx-8">
//         <Box className="flex gap-x-4">
//           <CloudIcon width="30px" />
//           <Box className="grow">
//             <ListItemText primary="Storage" />
//             <div className="progress-container my-3">
//               <div className="progress-bar" style={{ width: `60%` }}></div>
//             </div>
//             <Typography
//               variant="h1"
//               fontFamily="Roboto"
//               fontWeight="400"
//               fontSize="12px"
//               color={theme.palette.text.primary}
//             >
//               10 GB of 15 GB used
//             </Typography>
//             <Button
//               sx={{
//                 fontFamily: "Roboto !important",
//                 fontWeight: "500",
//                 fontSize: "15px",
//                 textTransform: "none",
//                 border: "1px solid #E01E26",
//                 color: "#E01E26",
//                 marginTop: "10px",
//                 "&:hover": {
//                   color: "#fff",
//                   backgroundColor: "var(--redColor)",

//                 },
//               }}
//               variant="outlined"
//             >
//               Upgrade
//             </Button>
//           </Box>
//         </Box>
//       </div>
//       <Box className="divider" />
//       <ListItemButton>
//         <ListItemIcon className="justify-center">
//           <SettingsIcon width="22" />
//         </ListItemIcon>
//         <ListItemText primary="Settings" />
//       </ListItemButton>
//       <ListItemButton>
//         <ListItemIcon className="justify-center">
//           <LogoutIcon width="22" />
//         </ListItemIcon>
//         <ListItemText primary="Logout" />
//       </ListItemButton>
//       {/* <Box height="500px" /> */}
//     </List>
//   );
// }
