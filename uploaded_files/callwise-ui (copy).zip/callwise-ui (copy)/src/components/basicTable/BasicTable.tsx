import React from "react";
import Table from "@mui/material/Table";
import "./BasicTable.scss";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { classNames } from "../../utils";
import { FlagIcon } from "../icons/flagIcon";

// Reusable table component
export default function ReusableTable({
  columns,
  rows,
  className = "",
  blackBorder = false,
  alignLeft = false,
  outlineHeader = false,
  hideHeader = false,
}) {
  return (
    <TableContainer
      className={classNames(
        `basic-table`,
        className,
        blackBorder ? "black-border" : "",
        outlineHeader ? "outline-header" : ""
      )}
      component={Paper}
    >
      <Table
        sx={{
          // minWidth: 650
          ...(hideHeader && {
            thead: {
              display: "none !important",
            },
          }),
        }}
        aria-label="simple table"
      >
        <TableHead>
          <TableRow
            sx={{
              "th:last-child": {
                width: "0%",
              },
            }}
          >
            {columns.map((column, i) => (
              <TableCell key={column.title + i} align={column.align}>
                {column.title}
              </TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row, i) => (
            <TableRow
              key={row + i}
              sx={{
                //  "&:last-child td, &:last-child th": { border: 0 }

                "td, th": {
                  borderColor: "var(--greyColor) !important",
                },
              }}
            >
              {Object.entries(row).map(([key, value], index) => (
                <TableCell
                  key={key + index}
                  className={`body-medium`}
                  align={(value as any).align}
                >
                  {key === "actions" ? (
                    <ActionsCell
                      align={(value as any).align}
                      actions={(value as any).value}
                    />
                  ) : key == "country" ? (
                    <FlagIcon
                      align={(value as any).align}
                      country={(value as any).value}
                    />
                  ) : key === "status" ? (
                    <StatusIndicator
                      align={(value as any).align}
                      status={(value as any).value}
                    />
                  ) : typeof (value as any).value !== "string" ? (
                    <div
                      className={classNames(
                        "flex",
                        (value as any).align == "left"
                          ? "justify-start"
                          : (value as any).align == "center"
                          ? "justify-center"
                          : "justify-end"
                      )}
                    >
                      {(value as any).value as any}
                    </div>
                  ) : (
                    ((value as any).value as any)
                  )}
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

export function ActionsCell({ align, actions }) {
  return (
    <div
      className={classNames(
        "flex gap-x-2 items-center",
        align == "left"
          ? "justify-start"
          : align == "center"
          ? "justify-center"
          : "justify-end"
      )}
    >
      {/* // <div className="relative flex justify-end min-w-[110px]"> */}
      {/* <div className="absolute inset-4	 flex items-center justify-end"> */}
      {actions.map((action, index) => (
        <div key={index + action} onClick={action.onClick}>
          <React.Fragment>{action.icon}</React.Fragment>
        </div>
      ))}
      {/* </div> */}
      {/* </div> */}
    </div>
  );
}

function StatusIndicator({ align, status }) {
  let indicatorColor = "";
  if (status === "Active") {
    indicatorColor = "var(--greenColor)";
  } else if (status === "Inactive") {
    indicatorColor = "var(--redColor)";
  }

  return (
    <div
      className={classNames(
        "flex",
        align == "left"
          ? "justify-start"
          : align == "center"
          ? "justify-center"
          : "justify-end"
      )}
    >
      <div
        className="w-4	h-4 rounded-full"
        style={{ backgroundColor: indicatorColor }}
      />
    </div>
  );
}

// import * as React from "react";
// import Table from "@mui/material/Table";
// import TableBody from "@mui/material/TableBody";
// import TableCell from "@mui/material/TableCell";
// import TableContainer from "@mui/material/TableContainer";
// import TableHead from "@mui/material/TableHead";
// import TableRow from "@mui/material/TableRow";
// import Paper from "@mui/material/Paper";
// import EditIcon from "../icons/edit";
// import DeleteIcon from "../icons/delete";
// import StatsIcon from "../icons/stats";
// import PauseIcon from "../icons/pause";

// function createData(
//   name: string,
//   calories: number,
//   fat: number,
//   carbs: number,
//   protein: number
// ) {
//   return { name, calories, fat, carbs, protein };
// }

// const rows = [
//   createData("Test", 159, 6.0, 24, 4.0),
//   createData("Test-1", 237, 9.0, 37, 4.3),
//   createData("Test-2", 262, 16.0, 24, 6.0),
//   createData("Test-3", 305, 3.7, 67, 4.3),
//   createData("Test-4", 356, 16.0, 49, 3.9),
// ];

// export default function BasicTable() {
//   return (
//     <TableContainer className="basic-table" component={Paper}>
//       <Table sx={{ minWidth: 650 }} aria-label="simple table">
//         <TableHead>
//           <TableRow>
//             <TableCell>Name</TableCell>
//             <TableCell align="right">Country</TableCell>
//             <TableCell align="right">Connected Calls</TableCell>
//             <TableCell align="right">Live</TableCell>
//             <TableCell align="right">Average Call Duration</TableCell>
//             <TableCell align="right">Total</TableCell>
//             <TableCell align="right">Status</TableCell>
//             <TableCell align="right">Actions</TableCell>
//           </TableRow>
//         </TableHead>
//         <TableBody>
//           {rows.map((row, i) => (
//             <TableRow
//               key={row.name}
//               sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
//             >
//               <TableCell className="body-medium" component="th" scope="row">
//                 {row.name}
//               </TableCell>
//               <TableCell className="body-medium" align="right">
//                 <div className="flex justify-end">
//                   <img
//                     src="https://flagcdn.com/16x12/us.png"
//                     width="16"
//                     height="12"
//                     alt="South Africa"
//                   />
//                 </div>
//               </TableCell>
//               <TableCell className="body-medium" align="right">
//                 {row.fat}
//               </TableCell>
//               <TableCell className="body-medium" align="right">
//                 {row.carbs}
//               </TableCell>
//               <TableCell className="body-medium" align="right">
//                 {row.protein}
//               </TableCell>
//               <TableCell className="body-medium" align="right">
//                 {row.protein}
//               </TableCell>
//               <TableCell className="body-medium" align="right">
//                 <div className="flex justify-end">
//                   {i % 2 == 0 ? (
//                     <div className="w-4	h-4 bg-[var(--greenColor)] rounded-full" />
//                   ) : (
//                     <div className="w-4	h-4 bg-[var(--redColor)] rounded-full" />
//                   )}
//                 </div>
//               </TableCell>
//               <TableCell className="body-medium" align="right">
//                 <div className="flex gap-x-4 justify-end">
//                   <EditIcon />
//                   <DeleteIcon />
//                   <StatsIcon />
//                   <PauseIcon />
//                 </div>
//               </TableCell>
//             </TableRow>
//           ))}
//         </TableBody>
//       </Table>
//     </TableContainer>
//   );
// }
